const fs=require('fs'),path=require('path');
fs.copyFileSync('node_modules/xlsx/dist/xlsx.full.min.js','www/xlsx.full.min.js');
// OCR engine (Tesseract) -> www/tess
fs.mkdirSync('www/tess',{recursive:true});
fs.copyFileSync('node_modules/tesseract.js/dist/tesseract.min.js','www/tess/tesseract.min.js');
fs.copyFileSync('node_modules/tesseract.js/dist/worker.min.js','www/tess/worker.min.js');
const cd='node_modules/tesseract.js-core';
const core=fs.readdirSync(cd).filter(f=>/^tesseract-core.*lstm.*\.(js|wasm)$/.test(f));
if(core.length<2)throw new Error('tesseract core files not found: '+fs.readdirSync(cd).join(','));
core.forEach(f=>fs.copyFileSync(path.join(cd,f),path.join('www/tess',f)));
(async()=>{
  for(const l of ['heb','eng']){
    const r=await fetch('https://github.com/tesseract-ocr/tessdata_fast/raw/main/'+l+'.traineddata');
    if(!r.ok)throw new Error('language data '+l+' http '+r.status);
    const b=Buffer.from(await r.arrayBuffer());
    if(b.length<500000)throw new Error('language data '+l+' too small: '+b.length);
    fs.writeFileSync('www/tess/'+l+'.traineddata',b);
  }
  console.log('OCR files:',fs.readdirSync('www/tess').join(' '));
})().catch(e=>{console.error(e);process.exit(1)});
